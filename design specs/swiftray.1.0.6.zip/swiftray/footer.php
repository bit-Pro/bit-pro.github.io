<div class="clear"></div>
</div>
<!--End Container--> 
<div class="footer_bg">
    <!--Start Container-->
    <div class="container_24">
        <!--Start Footer Wrapper-->
        <div class="grid_24 footer_wrapper">
            <!--Start Footer-->
            <?php
            /* A sidebar in the footer? Yep. You can can customize
             * your footer with four columns of widgets.
             */
            get_sidebar('footer');
            ?>
            <!--End Footer-->
        </div>
        <!--End Footer Wrapper-->
    </div>
    <!--End Container-->
</div>
</div>
<!--End Wrapper-->
<div class="container_24">
    <div class="grid_24 bottom_wrap">
        <div>
            <p class="copy_right"><a rel="nofollow" href="<?php echo esc_url('http://www.inkthemes.com'); ?>">Swiftray Theme&nbsp;</a>Powered by&nbsp;<a href="<?php echo esc_url('http://wordpress.org'); ?>">WordPress</a></p>
        </div>
    </div>
</div>
<?php wp_footer(); ?>
</body>
</html>
