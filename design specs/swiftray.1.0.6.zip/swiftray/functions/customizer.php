<?php

class Swiftray_Customizer {

    public static function Swiftray_Register($wp_customize) {
        self::Swiftray_Sections($wp_customize);
        self::Swiftray_Controls($wp_customize);
    }

    public static function Swiftray_Sections($wp_customize) {
        /**
         * General Section
         */
        $wp_customize->add_section('general_setting_section', array(
            'title' => __('General Settings', 'swiftray'),
            'description' => __('Allows you to customize header logo, favicon, background etc settings for Swiftray Theme.', 'swiftray'), //Descriptive tooltip
            'panel' => '',
            'priority' => '10',
            'capability' => 'edit_theme_options'
                )
        );
        /**
         * Add panel for home page feature area
         */
        $wp_customize->add_section('home_page_feature_area_panel', array(
            'title' => __('Home Page Feature Area', 'swiftray'),
            'description' => __('Allows you to setup home page feature area section for Swiftray Theme.', 'swiftray'),
            'priority' => '11',
            'capability' => 'edit_theme_options'
        ));
        /**
         * Style Section
         */
        $wp_customize->add_section('style_section', array(
            'title' => __('Style Setting', 'swiftray'),
            'description' => __('Allows you to setup Top Footer Section Text for Swiftray Theme.', 'swiftray'),
            'panel' => '',
            'priority' => '12',
            'capability' => 'edit_theme_options'
                )
        );
    }

    public static function Swiftray_Section_Content() {
        $section_content = array(
            'general_setting_section' => array(
                'inkthemes_logo',
                'inkthemes_favicon',
                'inkthemes_bodybg'
            ),
            'home_page_feature_area_panel' => array(
                'inkthemes_slideimage1'
            ),
            'style_section' => array(
                'inkthemes_customcss'
            )
        );
        return $section_content;
    }

    public static function Swiftray_Settings() {
        $swiftray_settings = array(
            'inkthemes_logo' => array(
                'id' => 'inkthemes_options[inkthemes_logo]',
                'label' => __('Custom Logo', 'swiftray'),
                'description' => __('Choose your own logo. Optimal Size: 221px Wide by 84px Height.', 'swiftray'),
                'type' => 'option',
                'setting_type' => 'image',
                'default' => ''
            ),
            'inkthemes_favicon' => array(
                'id' => 'inkthemes_options[inkthemes_favicon]',
                'label' => __('Custom Favicon', 'swiftray'),
                'description' => __('Here you can upload a Favicon for your Website. Specified size is 16px x 16px.', 'swiftray'),
                'type' => 'option',
                'setting_type' => 'image',
                'default' => ''
            ),
            'inkthemes_bodybg' => array(
                'id' => 'inkthemes_options[inkthemes_bodybg]',
                'label' => __('Body Background Image', 'swiftray'),
                'description' => __('Select image to change your website background', 'swiftray'),
                'type' => 'option',
                'setting_type' => 'image',
                'default' => ''
            ),
            // Top Feature Area
            'inkthemes_slideimage1' => array(
                'id' => 'inkthemes_options[inkthemes_slideimage1]',
                'label' => __('Upload Home Page Image', 'swiftray'),
                'description' => __('Choose Image for your homepage featured area. Optimal Size: 675px x 255px', 'swiftray'),
                'type' => 'option',
                'setting_type' => 'image',
                'default' => get_template_directory_uri() . '/images/image-fet.jpg'
            ),
            'inkthemes_customcss' => array(
                'id' => 'inkthemes_options[inkthemes_customcss]',
                'label' => __('Custom CSS', 'swiftray'),
                'description' => __('Quickly add your custom CSS code to your theme by writing the code in this block.', 'swiftray'),
                'type' => 'option',
                'setting_type' => 'textarea',
                'default' => ''
            ),
        );
        return $swiftray_settings;
    }

    public static function Swiftray_Controls($wp_customize) {
        $sections = self::Swiftray_Section_Content();
        $settings = self::Swiftray_Settings();
        foreach ($sections as $section_id => $section_content) {
            foreach ($section_content as $section_content_id) {
                switch ($settings[$section_content_id]['setting_type']) {
                    case 'image':
                        self::add_setting($wp_customize, $settings[$section_content_id]['id'], $settings[$section_content_id]['default'], $settings[$section_content_id]['type'], 'swiftray_sanitize_url');
                        $wp_customize->add_control(new WP_Customize_Image_Control(
                                $wp_customize, $settings[$section_content_id]['id'], array(
                            'label' => $settings[$section_content_id]['label'],
                            'description' => $settings[$section_content_id]['description'],
                            'section' => $section_id,
                            'settings' => $settings[$section_content_id]['id']
                                )
                        ));
                        break;
                    case 'text':
                        self::add_setting($wp_customize, $settings[$section_content_id]['id'], $settings[$section_content_id]['default'], $settings[$section_content_id]['type'], 'swiftray_sanitize_text');
                        $wp_customize->add_control(new WP_Customize_Control(
                                $wp_customize, $settings[$section_content_id]['id'], array(
                            'label' => $settings[$section_content_id]['label'],
                            'description' => $settings[$section_content_id]['description'],
                            'section' => $section_id,
                            'settings' => $settings[$section_content_id]['id'],
                            'type' => 'text'
                                )
                        ));
                        break;
                    case 'textarea':
                        self::add_setting($wp_customize, $settings[$section_content_id]['id'], $settings[$section_content_id]['default'], $settings[$section_content_id]['type'], 'swiftray_sanitize_textarea');

                        $wp_customize->add_control(new WP_Customize_Control(
                                $wp_customize, $settings[$section_content_id]['id'], array(
                            'label' => $settings[$section_content_id]['label'],
                            'description' => $settings[$section_content_id]['description'],
                            'section' => $section_id,
                            'settings' => $settings[$section_content_id]['id'],
                            'type' => 'textarea'
                                )
                        ));
                        break;
                    case 'link':

                        self::add_setting($wp_customize, $settings[$section_content_id]['id'], $settings[$section_content_id]['default'], $settings[$section_content_id]['type'], 'swiftray_sanitize_url');

                        $wp_customize->add_control(new WP_Customize_Control(
                                $wp_customize, $settings[$section_content_id]['id'], array(
                            'label' => $settings[$section_content_id]['label'],
                            'description' => $settings[$section_content_id]['description'],
                            'section' => $section_id,
                            'settings' => $settings[$section_content_id]['id'],
                            'type' => 'text'
                                )
                        ));

                        break;
                    default:
                        break;
                }
            }
        }
    }

    public static function add_setting($wp_customize, $setting_id, $default, $type, $sanitize_callback) {
        $wp_customize->add_setting($setting_id, array(
            'default' => $default,
            'capability' => 'edit_theme_options',
            'sanitize_callback' => array('Swiftray_Customizer', $sanitize_callback),
            'type' => $type
                )
        );
    }

    /**
     * adds sanitization callback funtion : textarea
     * @package Swiftray
     */
    public static function swiftray_sanitize_textarea($value) {
        $array = wp_kses_allowed_html('post');
        $allowedtags = array(
            'iframe' => array(
                'width' => array(),
                'height' => array(),
                'frameborder' => array(),
                'scrolling' => array(),
                'src' => array(),
                'marginwidth' => array(),
                'marginheight' => array()
            )
        );
        $data = array_merge($allowedtags, $array);
        $value = wp_kses($value, $data);
        return $value;
    }

    /**
     * adds sanitization callback funtion : url
     * @package Swiftray
     */
    public static function swiftray_sanitize_url($value) {
        $value = esc_url($value);
        return $value;
    }

    /**
     * adds sanitization callback funtion : text
     * @package Swiftray
     */
    public static function swiftray_sanitize_text($value) {
        $value = sanitize_text_field($value);
        return $value;
    }

    /**
     * adds sanitization callback funtion : email
     * @package Swiftray
     */
    public static function swiftray_sanitize_email($value) {
        $value = sanitize_email($value);
        return $value;
    }

    /**
     * adds sanitization callback funtion : number
     * @package Swiftray
     */
    public static function swiftray_sanitize_number($value) {
        $value = preg_replace("/[^0-9+ ]/", "", $value);
        return $value;
    }

}

// Setup the Theme Customizer settings and controls...
add_action('customize_register', array('Swiftray_Customizer', 'Swiftray_Register'));

function inkthemes_registers() {
    wp_register_script('inkthemes_jquery_ui', '//code.jquery.com/ui/1.11.0/jquery-ui.js', array("jquery"), true);
    wp_register_script('inkthemes_customizer_script', get_template_directory_uri() . '/functions/js/inkthemes_customizer.js', array("jquery", "inkthemes_jquery_ui"), true);
    wp_enqueue_script('inkthemes_customizer_script');
    wp_localize_script('inkthemes_customizer_script', 'ink_advert', array(
        'pro' => __('View PRO version', 'swiftray'),
        'url' => esc_url('http://www.inkthemes.com/wp-themes/fastest-wordpress-theme/'),
        'support_text' => __('Need Help!', 'swiftray'),
        'support_url' => esc_url('http://www.inkthemes.com/lets-connect/')
            )
    );
}

add_action('customize_controls_enqueue_scripts', 'inkthemes_registers');
