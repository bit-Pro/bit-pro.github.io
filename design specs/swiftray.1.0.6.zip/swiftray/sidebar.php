<div class="sidebar">
    <!--Start Menu-->
    <div id="menu-wrapper">
        <?php inkthemes_nav(); ?>
    </div>
    <!--End Menu-->
    <div class="clear"></div>
    <div class="clear"></div>  
    <div class="sidebar_widget">
        <?php
        if (!is_active_sidebar('primary-widget-area')) :
            dynamic_sidebar('primary-widget-area');
        endif; // end primary widget area 
        // A second sidebar for widgets, just because.
        if (is_active_sidebar('secondary-widget-area')) :
            dynamic_sidebar('secondary-widget-area');
        endif;
        ?>  
    </div>
</div>