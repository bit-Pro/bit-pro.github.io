<!-- Start the Loop. -->
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <div class="post_content"> 
                <?php
                if (has_post_thumbnail()) {
                    inkthemes_get_thumbnail(146, 168);
                } else {
                    inkthemes_get_image(146, 168);
                }
                ?>	
                <h1 class="post_title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php printf(__('Permanent Link to %s', 'swiftray'), the_title_attribute('echo=0')); ?>"><?php the_title(); ?></a></h1>
                <ul class="post_meta">
                    <li><?php echo get_the_time('F j, Y') ?></li>
                    <li><?php _e('Posted in', 'swiftray'); ?> <?php the_category(', '); ?></li>
                    <li><?php _e('By', 'swiftray'); ?> <?php the_author_posts_link(); ?></li>
                    <li><?php comments_popup_link(__('No Comments.', 'swiftray'), __('1 Comment.', 'swiftray'), __('% Comments.', 'swiftray')); ?></li>
                </ul>
                <?php the_excerpt(); ?>
                <div class="clear"></div>
                <?php if (has_tag()) { ?>
                    <div class="tag">
                        <?php the_tags(__('Post Tagged with&nbsp;', 'swiftray'), ', ', ''); ?>
                    </div>
                <?php } ?>
                <div class="clear"></div>
            </div>
            <a class="read-more" href="<?php the_permalink() ?>"><?php _e('Read More', 'swiftray'); ?></a>
            <div class="clear"></div>
            <div class="dt_line"></div>
        </div>
        <?php
    endwhile;
else:
    ?>
    <div class="post">
        <p>
            <?php _e('Sorry, no posts matched your criteria.', 'swiftray'); ?>
        </p>
    </div>
<?php endif; ?>
<!--End Loop-->